# python-challenge
Python Assignment I : UCSD Extension - Data Science
